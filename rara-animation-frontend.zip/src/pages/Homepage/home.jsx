import React, { useEffect } from "react";
import "./index.css";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Draggable } from "gsap/Draggable";

import headOpenBGImage from "../../assets/home/images/b-vision_illust01.png";
import handOpenBGImage from "../../assets/home/images/b-vision_illust08.png";

gsap.registerPlugin(ScrollTrigger, Draggable);

const index = () => {
  useEffect(() => {
    const canvas = document.querySelector("#canvas1");

    const canvasContainer = document.querySelector(".spacer");
    console.log("CNAVAS CONTAINER------------", canvasContainer);

    const spacerHeight = canvasContainer.clientHeight;

    // Calculate 1% of window's height
    const scrollLimit = spacerHeight * 0.01;

    const scrollContainer = document.querySelector(".custom-container");

    const c = canvas.getContext("2d");

    canvas.width = document.documentElement.clientWidth;
    canvas.height = document.documentElement.clientHeight;

    canvas.style.width = document.documentElement.clientWidth;
    +"px";
    canvas.style.height = document.documentElement.clientHeight;
    +"px";

    const mouse = {
      x: innerWidth / 2,
      y: innerHeight / 2,
    };

    let prevMouseX = null;
    let prevMouseY = null;

    let deltaX = null;
    let deltaY = null;

    const colors = ["#2185C5", "#7ECEFD", "#FFF6E5", "#FF7F66"];

    const timeline = gsap.timeline();

    const canvasScroll = gsap.to("#canvas1", {
      scrollTrigger: {
        trigger: "#canvas1",
        scroller: scrollContainer,
        start: "top top",
        end: "+=1%",
        scrub: true,
        pin: true, // pin the canvas in place
        anticipatePin: 1, // 1 means it will anticipate the pin and unpin before they happen.
      },
    });

    // Attach an event listener to the canvas for the mousemove event
    canvas.addEventListener("mousemove", (event) => {
      const rect = canvas.getBoundingClientRect();
      const mouseX = event.clientX - rect.left;
      const mouseY = event.clientY - rect.top;

      if (prevMouseX !== null && prevMouseY !== null) {
        deltaX = mouseX - prevMouseX;
        deltaY = mouseY - prevMouseY;
        // console.log("MOUSE X ------", mouseX);

        images.forEach((image) => {
          let imageX = null;
          let imageY = null;

          if (Math.abs(deltaX) > Math.abs(deltaY)) {
            if (deltaX > 0) {
              // console.log("Right--");
              if (mouseX == innerWidth / 2) {
                // image.x = image.x1;
              } else {
                image.x = image.x - 0.1;
              }
            } else {
              if (mouseX == innerWidth / 2) {
                // image.x = image.x1;
              } else {
                image.x = image.x + 0.1;
              }
              // console.log("Left---", deltaX);
            }
          } else {
            if (deltaY > 0) {
              if (mouseY == innerHeight / 2) {
                // image.y = image.y1;
              } else {
                image.y = image.y - 0.1;
              }
              // Mouse is moving down
              // console.log("Down");
            } else {
              if (mouseY == innerHeight / 2) {
                // image.y = image.y1;
              } else {
                // Mouse is moving up
                image.y = image.y + 0.1;
              }
              // console.log("Up");
            }
          }
        });
      }

      prevMouseX = mouseX;
      prevMouseY = mouseY;
    });

    window.addEventListener("resize", () => {
      canvas.width = document.documentElement.clientWidth;
      canvas.height = document.documentElement.clientHeight;

      init();
    });

    const responsiveCircleValues = [
      {
        screenWidth: 320,
        width: canvas.width / 2,
        height: canvas.height / 2.25,
        radius: canvas.width / 3.1,
      },
      {
        screenWidth: 380,
        width: canvas.width / 2,
        height: canvas.height / 2.35,
        radius: canvas.width / 3.1,
      },
      {
        screenWidth: 480,
        width: canvas.width / 2,
        height: canvas.height / 2.25,
        radius: canvas.width / 3,
      },
      {
        screenWidth: 768,
        width: canvas.width / 2,
        height: canvas.height / 2,
        radius: canvas.width / 6,
      },
      {
        screenWidth: 1024,
        width: canvas.width / 2,
        height: canvas.height / 2,
        radius: canvas.width / 6,
      },
      {
        screenWidth: 1440,
        width: canvas.width / 2,
        height: canvas.height / 2,
        radius: canvas.width / 7,
      },
      {
        screenWidth: 1920,
        width: canvas.width / 2,
        height: canvas.height / 2,
        radius: canvas.width / 7,
      },
      {
        screenWidth: 2500,
        width: canvas.width / 2,
        height: canvas.height / 2,
        radius: canvas.width / 7,
      },
      // Add more rules for larger screens if needed
    ];

    function getResponsiveCircleRadius(screenWidth) {
      let circleWidth = canvas.width / 2;
      let circleHeight = canvas.height / 2;
      let circleRadius = canvas.height / 2.9;

      for (const rule of responsiveCircleValues) {
        if (screenWidth <= rule.screenWidth) {
          circleWidth = rule.width;
          circleHeight = rule.height;
          circleRadius = rule.radius;
          break;
        }
      }

      return { circleWidth, circleHeight, circleRadius };
    }

    // Objects
    function Circle(x, y, radius, color, updatedX, updatedY, updatedRadius) {
      this.x = x;
      this.y = y;
      this.radius = radius;
      this.color = color;

      this.updatedX = updatedX;
      this.updatedY = updatedY;
      this.updatedRadius = updatedRadius;

      this.update = () => {
        this.draw();
      };

      this.draw = () => {
        c.beginPath();
        c.arc(this.x, this.y, this.radius, 0, 2 * Math.PI, false);
        c.lineWidth = 1;
        c.strokeStyle = this.color;
        c.stroke();
      };

      if (this.updatedX != undefined && this.updatedY != undefined) {
        const timeline = gsap.timeline();
        timeline.to(this, {
          x: this.updatedX,
          y: this.updatedY,
          radius: this.updatedRadius,
          scrollTrigger: {
            trigger: ".spacer",
            scroller: scrollContainer,
            start: "top top",
            end: "+=1%",
            scrub: 1,
            animate: true,
          },
          onUpdate: () => {
            this.update();
          },
        });
      }
    }

    const responsiveEllipseValues = [
      {
        screenWidth: 320,
        width: canvas.width / 2,
        height: canvas.height / 2.2,
        radius: canvas.width / 1.7,
        verticalScale: canvas.width / 1.7,
      },
      {
        screenWidth: 380,
        width: canvas.width / 2,
        height: canvas.height / 2.3,
        radius: canvas.width / 1.6,
        verticalScale: canvas.width / 1.6,
      },
      {
        screenWidth: 480,
        width: canvas.width / 2,
        height: canvas.height / 2.2,
        radius: canvas.width / 1.7,
        verticalScale: canvas.width / 1.7,
      },
      {
        screenWidth: 768,
        width: canvas.width / 2,
        height: canvas.height / 2,
        radius: canvas.height / 2.7,
        verticalScale: canvas.height / 2.7,
      },
      {
        screenWidth: 1024,
        width: canvas.width / 2,
        height: canvas.height / 2,
        radius: canvas.width / 3,
        verticalScale: canvas.width / 3,
      },
      {
        screenWidth: 1440,
        width: canvas.width / 2,
        height: canvas.height / 2,
        radius: canvas.width / 3.5,
        verticalScale: canvas.width / 3.5,
      },
      {
        screenWidth: 1920,
        width: canvas.width / 2,
        height: canvas.height / 2,
        radius: canvas.width / 3.5,
        verticalScale: canvas.width / 3.5,
      },
      {
        screenWidth: 2500,
        width: canvas.width / 2,
        height: canvas.height / 2,
        radius: canvas.width / 3.5,
        verticalScale: canvas.width / 3.5,
      },
      // Add more rules for larger screens if needed
    ];
    function getResponsiveEllipseDimensions(screenWidth) {
      let width = canvas.width / 2;
      let height = canvas.height / 2;
      let radius = canvas.height / 1.55;
      let verticalScale = canvas.height / 1.55;

      for (const rule of responsiveEllipseValues) {
        if (screenWidth <= rule.screenWidth) {
          width = rule.width;
          height = rule.height;
          radius = rule.radius;
          verticalScale = rule.verticalScale;
          break;
        }
      }

      return { width, height, radius, verticalScale };
    }

    function Ellipse(
      x,
      y,
      radius,
      verticalScale,
      color,
      updatedX,
      updatedY,
      updatedRadius,
      updatedVerticalScale
    ) {
      this.x = x;
      this.y = y;
      this.radius = radius;
      this.color = color;
      this.radians = 0;
      this.velocity = 0.05;
      this.verticalScale = verticalScale;

      this.updatedX = updatedX;
      this.updatedY = updatedY;
      this.updatedRadius = updatedRadius;
      this.updatedVerticalScale = updatedVerticalScale;

      this.update = () => {
        this.draw();
      };

      this.draw = () => {
        c.beginPath();
        c.ellipse(
          this.x,
          this.y,
          this.radius,
          this.verticalScale,
          0,
          0,
          2 * Math.PI,
          false
        );
        c.lineWidth = 1;
        c.strokeStyle = this.color;
        c.stroke();
      };

      if (this.updatedX != undefined && this.updatedY != undefined) {
        const timeline = gsap.timeline();
        timeline.to(this, {
          x: this.updatedX,
          y: this.updatedY,
          radius: this.updatedRadius,
          verticalScale: this.updatedVerticalScale,
          scrollTrigger: {
            trigger: ".spacer",
            scroller: scrollContainer,
            start: "top top",
            end: "+=1%",
            scrub: 0.4,
            animate: true,
          },
          onUpdate: () => {
            this.draw();
          },
        });
      }
    }

    function CircleWithEllipseRotation(
      x,
      y,
      radius,
      color,
      radians,
      velocity,
      verticalScaleX,
      verticalScaleY,
      updatedX,
      updatedY,
      updatedRadius,
      updatedRadian,
      updatedVelocity,
      updatedVerticalScaleX,
      updatedVerticalScaleY
    ) {
      this.x = x;
      this.y = y;
      this.radius = radius;
      this.color = color;
      this.radians = radians;
      this.velocity = velocity;
      this.verticalScaleX = verticalScaleX;
      this.verticalScaleY = verticalScaleY;

      this.updatedX = updatedX;
      this.updatedY = updatedY;
      this.updatedRadius = updatedRadius;
      this.updatedRadian = updatedRadian;
      this.updatedVelocity = updatedVelocity;
      this.updatedVerticalScaleX = updatedVerticalScaleX;
      this.updatedVerticalScaleY = updatedVerticalScaleY;

      if (radians != undefined) {
        this.radians = radians;
      } else {
        this.radians = 0;
      }
      if (velocity != undefined) {
        this.velocity = velocity;
      } else {
        this.velocity = 0;
      }
      if (verticalScaleX != undefined) {
        this.verticalScaleX = verticalScaleX;
      } else {
        this.verticalScaleX = 0;
      }
      if (verticalScaleY != undefined) {
        this.verticalScaleY = verticalScaleY;
      } else {
        this.verticalScaleY = 0;
      }

      this.update = () => {
        if (
          velocity != undefined &&
          radians != undefined &&
          verticalScaleX != undefined &&
          verticalScaleY != undefined
        ) {
          this.radians += this.velocity;
          // Calculating position of revolving circle
          this.x = this.updatedX + this.verticalScaleX * Math.cos(this.radians);
          this.y = this.updatedY + this.verticalScaleY * Math.sin(this.radians);
        }
        this.draw();
      };

      this.draw = (circleX, circleY) => {
        c.beginPath();
        c.arc(this.x, this.y, this.radius, 0, Math.PI * 2, false);
        c.fillStyle = this.color;
        c.fill();
        c.closePath();
      };

      if (this.updatedX != undefined && this.updatedY != undefined) {
        const timeline = gsap.timeline();
        timeline.to(this, {
          x: this.updatedX,
          y: this.updatedY,
          radius: this.updatedRadius,
          radians: this.updatedRadian,
          velocity: this.updatedVelocity,
          verticalScaleX: this.updatedVerticalScaleX,
          verticalScaleY: this.updatedVerticalScaleY,
          scrollTrigger: {
            trigger: ".spacer",
            scroller: scrollContainer,
            start: "top top",
            end: "+=1%",
            scrub: 1,
            animate: true,
          },
          onUpdate: () => {
            this.update();
          },
        });
      }
    }

    function FilledCircle(
      x,
      y,
      radius,
      color,
      radian,
      velocity,
      distanceFromCenter,
      updatedX,
      updatedY,
      updatedRadius,
      updatedRadian,
      updatedDistance
    ) {
      this.x = x;
      this.y = y;
      this.radius = radius;
      this.color = color;

      this.updatedX = updatedX;
      this.updatedY = updatedY;
      this.updatedRadius = updatedRadius;
      this.updatedRadian = updatedRadian;
      this.updatedDistance = updatedDistance;

      if (radian != undefined) {
        this.radians = radian;
      } else {
        this.radians = 0;
      }
      if (velocity != undefined) {
        this.velocity = velocity;
      } else {
        this.velocity = 0;
      }
      if (distanceFromCenter != undefined) {
        this.distanceFromCenter = distanceFromCenter;
      } else {
        this.distanceFromCenter = 0;
      }

      // console.log("RADian --------", canvas.width, "------------", canvas.height);

      // update(x, y, radius, color, this.radian);
      this.update = () => {
        if (
          velocity != undefined &&
          radian != undefined &&
          distanceFromCenter != undefined
        ) {
          this.radians += this.velocity;
          this.x = x + Math.cos(this.radians) * this.distanceFromCenter;
          this.y = y + Math.sin(this.radians) * this.distanceFromCenter;
        }

        this.draw();
      };

      this.draw = () => {
        c.beginPath();
        c.arc(this.x, this.y, this.radius, 0, Math.PI * 2, false);
        c.fillStyle = this.color;
        c.fill();
        c.closePath();
      };

      if (this.updatedX != undefined && this.updatedY != undefined) {
        const timeline = gsap.timeline();
        timeline.to(this, {
          x: this.updatedX,
          y: this.updatedY,
          radius: this.updatedRadius,
          radian: this.updatedRadian,
          distanceFromCenter: this.updatedDistance,
          scrollTrigger: {
            trigger: ".spacer",
            scroller: scrollContainer,
            start: "top top",
            end: "+=1%",
            scrub: 1,
            animate: true,
          },
          onUpdate: () => {
            this.update();
          },
        });
      }
    }

    function UploadedCenterImage(
      x,
      y,
      image,
      width,
      height,
      rotation,
      updatedX,
      updatedY,
      updatedWidth,
      updatedHeight,
      updatedRotation
    ) {
      this.x = x;
      this.y = y;
      this.x1 = x;
      this.y1 = y;
      this.image = image;
      this.width = width;
      this.height = height;

      this.updatedX = updatedX;
      this.updatedY = updatedY;
      this.updatedWidth = updatedWidth;
      this.updatedHeight = updatedHeight;

      this.rotation = rotation;

      this.updatedRotation = updatedRotation;

      const newImage = new Image();
      newImage.src = this.image;

      newImage.onload = () => {
        this.draw();

        if (this.updatedImage) {
          newImage.src = this.updatedImage;
        }

        if (
          this.updatedX != undefined &&
          this.updatedY != undefined &&
          this.updatedWidth != undefined
        ) {
          const timeline = gsap.timeline();
          timeline.to(this, {
            x: this.updatedX,
            y: this.updatedY,
            width: this.updatedWidth,
            height: this.updatedHeight,
            rotation: updatedRotation ? updatedRotation : 0,
            scrollTrigger: {
              trigger: document.body,
              start: "top top",
              end: "+=1%",
              scrub: 1,
              animate: true,
            },
            onUpdate: () => {
              this.draw();
            },
          });
        }
      };

      this.update = () => {
        this.draw();
      };

      this.draw = () => {
        c.globalAlpha = 1;
        // c.drawImage(newImage, this.x, this.y, this.width, this.height);
        // Save the canvas state before applying rotation
        const drawHeight = this.updatedHeight
          ? this.updatedHeight / 2
          : this.height / 2;
        if (this.rotation || this.updatedRotation) {
          c.save(); // Save the original state
          c.translate(this.x + this.width / 2, this.y + this.height / 2); // Move to the center of the image
          c.rotate((this.rotation * Math.PI) / 180); // Convert degrees to radians and rotate
          c.drawImage(
            newImage,
            -this.width / 2,
            -drawHeight / 2,
            this.width,
            drawHeight
          ); // Draw the image back, but offset by half its dimensions
          c.restore(); // Restore the original state
        } else {
          c.drawImage(newImage, this.x, this.y, this.width, this.height / 2);
        }
      };
    }

    function UploadedImage(
      x,
      y,
      image,
      width,
      height,
      rotation,
      updatedX,
      updatedY,
      updatedWidth,
      updatedHeight,
      updatedRotation
    ) {
      this.x = x;
      this.y = y;
      this.x1 = x;
      this.y1 = y;
      this.image = image;
      this.width = width;
      this.height = height;

      this.updatedX = updatedX;
      this.updatedY = updatedY;
      this.updatedWidth = updatedWidth;
      this.updatedHeight = updatedHeight;

      this.rotation = rotation;

      this.updatedRotation = updatedRotation;

      const newImage = new Image();
      newImage.src = this.image;

      newImage.onload = () => {
        this.draw();

        if (this.updatedImage) {
          newImage.src = this.updatedImage;
        }

        if (
          this.updatedX != undefined &&
          this.updatedY != undefined &&
          this.updatedWidth != undefined
        ) {
          const timeline = gsap.timeline();
          78;
          timeline.to(this, {
            x: this.updatedX,
            y: this.updatedY,
            width: this.updatedWidth,
            height: this.updatedHeight,
            rotation: updatedRotation ? updatedRotation : 0,
            scrollTrigger: {
              trigger: ".spacer",
              scroller: scrollContainer,
              start: "top top",
              end: "+=1%",
              scrub: 1,
              onUpdate: (self) => {
                this.draw();
              },
            },
          });
        }
      };

      this.update = () => {
        this.draw();
      };

      this.draw = () => {
        c.globalAlpha = 1;
        // c.drawImage(newImage, this.x, this.y, this.width, this.height);
        // Save the canvas state before applying rotation
        if (this.rotation || this.updatedRotation) {
          c.save(); // Save the original state
          c.translate(this.x + this.width / 2, this.y + this.height / 2); // Move to the center of the image
          c.rotate((this.rotation * Math.PI) / 180); // Convert degrees to radians and rotate
          c.drawImage(
            newImage,
            -this.width / 2,
            -this.height / 2,
            this.width,
            this.height
          ); // Draw the image back, but offset by half its dimensions
          c.restore(); // Restore the original state
        } else {
          c.drawImage(newImage, this.x, this.y, this.width, this.height);
        }
      };
    }

    function UploadedImageTransparent(
      x,
      y,
      image,
      width,
      height,
      rotation,
      updatedX,
      updatedY,
      updatedWidth,
      updatedHeight,
      updatedRotation,
      opacity
    ) {
      this.x = x;
      this.y = y;
      this.x1 = x;
      this.y1 = y;
      this.image = image;
      this.width = width;
      this.height = height;

      this.updatedX = updatedX;
      this.updatedY = updatedY;
      this.updatedWidth = updatedWidth;
      this.updatedHeight = updatedHeight;

      this.rotation = rotation;

      this.updatedRotation = updatedRotation;
      this.opacity = opacity;

      const newImage = new Image();
      newImage.src = this.image;

      newImage.onload = () => {
        this.draw();

        if (this.updatedImage) {
          newImage.src = this.updatedImage;
        }

        if (
          this.updatedX != undefined &&
          this.updatedY != undefined &&
          this.updatedWidth != undefined
        ) {
          const timeline = gsap.timeline();
          timeline.to(this, {
            x: this.updatedX,
            y: this.updatedY,
            width: this.updatedWidth,
            height: this.updatedHeight,
            rotation: updatedRotation ? updatedRotation : 0,
            scrollTrigger: {
              trigger: ".spacer",
              scroller: scrollContainer,
              start: "top top",
              end: "+=1%",
              scrub: 1,
              animate: true,
            },
            onUpdate: () => {
              this.draw();
            },
          });
        }
      };

      this.update = () => {
        this.draw();
      };

      this.draw = () => {
        c.globalAlpha = this.opacity != undefined ? this.opacity : 0.5;
        // c.drawImage(newImage, this.x, this.y, this.width, this.height);
        // Save the canvas state before applying rotation
        if (this.rotation || this.updatedRotation) {
          c.save(); // Save the original state
          c.translate(this.x + this.width / 2, this.y + this.height / 2); // Move to the center of the image
          c.rotate((this.rotation * Math.PI) / 180); // Convert degrees to radians and rotate
          c.drawImage(
            newImage,
            -this.width / 2,
            -this.height / 2,
            this.width,
            this.height
          ); // Draw the image back, but offset by half its dimensions
          c.restore(); // Restore the original state
        } else {
          c.drawImage(newImage, this.x, this.y, this.width, this.height);
        }
      };
    }

    // Implementation
    let circles;
    let images;

    let staticImages;
    let circleAboveImages;

    let imageDummy;

    let images1;

    function init() {
      const screenWidth = document.documentElement.clientWidth;
      console.log("SCREEN WIDTH 11111111111", screenWidth);

      circles = [];
      images = [];
      staticImages = [];
      circleAboveImages = [];
      imageDummy = [];

      images1 = [];

      imageDummy.push(
        new UploadedImageTransparent(
          0,
          30,
          require("../../assets/home/images/header_60.png"),
          innerWidth,
          innerHeight
        )
      );

      circles.push(
        new FilledCircle(
          canvas.width / 2,
          canvas.height / 2,
          25,
          "#af292f",
          0,
          0.0002,
          700,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0,
          0
        )
      );
      circles.push(
        new FilledCircle(
          canvas.width / 2,
          canvas.height / 2,
          25,
          "#af292f",
          3.125,
          0.0002,
          700,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0,
          0
        )
      );
      const { width, height, radius, verticalScale } =
        getResponsiveEllipseDimensions(screenWidth);
      console.log("WIDTH -0---------", width);

      circles.push(
        new Ellipse(
          width,
          height,
          radius,
          verticalScale,
          "grey",
          canvas.width / 2,
          canvas.height / 2,
          0,
          0
        )
      );

      const { circleWidth, circleHeight, circleRadius } =
        getResponsiveCircleRadius(screenWidth);
      console.log("CIRCLE WIDTH -------", circleWidth);
      circles.push(
        new Circle(
          circleWidth,
          circleHeight,
          circleRadius,
          "grey",
          canvas.width / 2,
          canvas.height / 2,
          0
        )
      );
      circles.push(
        new FilledCircle(
          canvas.width / 2,
          canvas.height / 2,
          5,
          "#af292f",
          0.75,
          0.001,
          130,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0,
          0
        )
      );
      circles.push(
        new FilledCircle(
          canvas.width / 2,
          canvas.height / 2,
          10,
          "rgb(91, 146, 157)",
          4.125,
          0.001,
          125,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0,
          0
        )
      );
      circles.push(
        new FilledCircle(
          canvas.width / 2,
          canvas.height / 2,
          10,
          "#af292f",
          0,
          0.001,
          305,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0,
          0
        )
      );
      circles.push(
        new FilledCircle(
          canvas.width / 2,
          canvas.height / 2,
          10,
          "#af292f",
          3.125,
          0.001,
          305,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0,
          0
        )
      );

      // Ellipse when scrolled down --- done

      circleAboveImages.push(
        new Ellipse(
          canvas.width / 2,
          canvas.height / 2,
          0,
          0,
          "#ADADAD",
          canvas.width / 2,
          canvas.height / 2,
          615,
          215
        )
      );

      // Ellipse rotating circle when scrolled down --- done
      circleAboveImages.push(
        new CircleWithEllipseRotation(
          canvas.width / 2,
          canvas.height / 2,
          0,
          "rgb(91, 146, 157)",
          0,
          0,
          0,
          0,
          canvas.width / 2,
          canvas.height / 2,
          10,
          0.1,
          0.003,
          615,
          215
        )
      );
      circleAboveImages.push(
        new CircleWithEllipseRotation(
          canvas.width / 2,
          canvas.height / 2,
          0,
          "#af292f",
          0,
          0,
          0,
          0,
          canvas.width / 2,
          canvas.height / 2,
          5,
          0.1,
          0.003,
          -615,
          -215
        )
      );

      circleAboveImages.push(
        new CircleWithEllipseRotation(
          canvas.width / 2,
          canvas.height / 2,
          0,
          "#af292f",
          0,
          0,
          0,
          0,
          canvas.width / 2,
          canvas.height / 2,
          10,
          17.3,
          0.003,
          615,
          215
        )
      );

      circleAboveImages.push(
        new CircleWithEllipseRotation(
          canvas.width / 2,
          canvas.height / 2,
          0,
          "#af292f",
          0,
          0,
          0,
          0,
          canvas.width / 2,
          canvas.height / 2,
          10,
          -4.7,
          0.003,
          615,
          215
        )
      );

      // R alphabet --- DONE

      images.push(
        new UploadedImage(
          35,
          canvas.height - 165,
          require("../../assets/home/images/header_48.png"),
          65,
          65,
          -15,
          canvas.width / 2 - 275,
          canvas.height / 2 - 85,
          97,
          95,
          0
        )
      );

      // building with two red lines and left of center --- done
      images.push(
        new UploadedImage(
          canvas.width / 2,
          canvas.height / 2,
          require("../../assets/home/images/header_32.png"),
          0,
          0,
          0,
          canvas.width / 2 - 270,
          canvas.height / 2 - 90,
          315,
          150
        )
      );

      // Rock with red label --- done
      images.push(
        new UploadedImage(
          canvas.width / 2,
          canvas.height / 2,
          require("../../assets/home/images/header_28.png"),
          0,
          0,
          0,
          canvas.width / 2 + 45,
          canvas.height / 2 - 95,
          170,
          125
        )
      );

      // tower with clock center --- done
      images.push(
        new UploadedImage(
          canvas.width / 2,
          canvas.height / 2,
          require("../../assets/home/images/header_29.png"),
          0,
          0,
          0,
          canvas.width / 2 - 115,
          canvas.height / 2 - 135,
          215,
          200
        )
      );

      // A alphabet ---- done

      images.push(
        new UploadedImage(
          canvas.width - 115,
          canvas.height / 2 - 140,
          require("../../assets/home/images/header_31.png"),
          40,
          30,
          -40,
          canvas.width / 2 + 145,
          canvas.height / 2 - 45,
          115,
          85,
          95
        )
      );

      // man with hand direction ---- done
      images.push(
        new UploadedImage(
          canvas.width,
          canvas.height / 2 - 15,
          require("../../assets/home/images/header_22.png"),
          115,
          150,
          0,
          canvas.width / 2 + 195,
          canvas.height / 2 + 15,
          115,
          160
        )
      );

      // roof with red top --- done
      images.push(
        new UploadedImage(
          canvas.width / 2,
          canvas.height / 2,
          require("../../assets/home/images/header_34.png"),
          0,
          0,
          0,
          canvas.width / 2 + 45,
          canvas.height / 2 - 15,
          185,
          150
        )
      );

      // red book ---- done

      images.push(
        new UploadedImage(
          canvas.width / 2 + 220,
          canvas.height / 2 - 220,
          require("../../assets/home/images/header_36.png"),
          100,
          95,
          0,
          canvas.width / 2 + 140,
          canvas.height / 2 - 130,
          45,
          35
        )
      );

      // car image --- done

      images.push(
        new UploadedImage(
          canvas.width / 2 + 375,
          canvas.height / 2 - 210,
          require("../../assets/home/images/header_25.png"),
          245,
          150,
          0,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0
        )
      );

      // dryer --- done

      images.push(
        new UploadedImage(
          canvas.width - 335,
          canvas.height / 2 - 250,
          require("../../assets/home/images/header_21.png"),
          200,
          105,
          0,
          canvas.width / 2 + 230,
          canvas.height / 2 - 75,
          90,
          50
        )
      );

      // R alphabet center --- done

      images.push(
        new UploadedImage(
          canvas.width / 2 + 465,
          canvas.height / 2 + 100,
          require("../../assets/home/images/header_52_1.png"),
          85,
          100,
          -45,
          canvas.width / 2 + 3,
          canvas.height / 2 - 90,
          80,
          100
        )
      );

      // slim man with glasses ---done

      images.push(
        new UploadedImage(
          1200,
          -500,
          require("../../assets/home/images/header_39.png"),
          110,
          170,
          0,
          canvas.width / 2 - 55,
          canvas.height / 2 - 52,
          115,
          160,
          0,
          0.5
        )
      );

      // girl --- done
      images.push(
        new UploadedImage(
          canvas.width / 2 + 205,
          canvas.height / 2 - 255,
          require("../../assets/home/images/header_9.png"),
          300,
          340,
          0,
          canvas.width / 2 - 0,
          canvas.height / 2 - 33,
          170,
          175
        )
      );

      //girl circle ---- DONE

      images.push(
        new UploadedImage(
          canvas.width / 2 + 400,
          canvas.height / 2 - 145,
          require("../../assets/home/images/header_6.png"),
          200,
          130,
          0,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0
        )
      );

      // man with joined hand --- done
      images.push(
        new UploadedImage(
          canvas.width / 2 + 300,
          canvas.width,
          require("../../assets/home/images/header_42.png"),
          100,
          135,
          0,
          canvas.width / 2 + 95,
          canvas.height / 2 + 40,
          95,
          125
        )
      );

      // black rock front of girl and behind book lady --- done
      images.push(
        new UploadedImage(
          canvas.width / 2,
          canvas.height / 2,
          require("../../assets/home/images/header_35.png"),
          0,
          0,
          0,
          canvas.width / 2,
          canvas.height / 2 + 80,
          200,
          75
        )
      );

      // eye --- done
      images.push(
        new UploadedImage(
          canvas.width / 2 + 355,
          canvas.height / 2 + 150,
          require("../../assets/home/images/header_8.png"),
          275,
          215,
          0,
          canvas.width / 2 + 105,
          canvas.height / 2 + 100,
          130,
          95
        )
      );

      // Leaf --- done

      images.push(
        new UploadedImage(
          canvas.width - 225,
          canvas.height / 2 - 85,
          require("../../assets/home/images/header_50.png"),
          150,
          115,
          0,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0
        )
      );

      // person above the cart --- done

      images.push(
        new UploadedImage(
          canvas.width - 91,
          canvas.height / 2 - 75,
          require("../../assets/home/images/header_17.png"),
          50,
          100,
          0,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0
        )
      );

      // cart --- done

      images.push(
        new UploadedImage(
          canvas.width - 185,
          canvas.height / 2 - 20,
          require("../../assets/home/images/header_33.png"),
          230,
          255,
          0,
          canvas.width / 2 + 285,
          canvas.height / 2 - 30,
          75,
          85
        )
      );

      // person on phone bottom right corner

      images.push(
        new UploadedImage(
          canvas.width - 130,
          canvas.height - 153,
          require("../../assets/home/images/header_27.png"),
          115,
          135,
          -15,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0
        )
      );

      // researcher person --- done

      images.push(
        new UploadedImage(
          canvas.width / 2 - 35,
          canvas.height / 2 + 101,
          require("../../assets/home/images/header_41.png"),
          80,
          130,
          0,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0
        )
      );

      // boy left to glasses man --- done
      images.push(
        new UploadedImage(
          canvas.width / 2,
          canvas.height / 2,
          require("../../assets/home/images/header_61.png"),
          0,
          0,
          0,
          canvas.width / 2 - 195,
          canvas.height / 2 - 60,
          75,
          105
        )
      );

      // building with speaker --- done

      images.push(
        new UploadedImage(
          canvas.width / 2,
          canvas.height / 2,
          require("../../assets/home/images/header_37.png"),
          0,
          0,
          0,
          canvas.width / 2 - 247,
          canvas.height / 2 - 13,
          200,
          100
        )
      );

      //glasses peron --- DONE

      images.push(
        new UploadedImage(
          265,
          canvas.height / 2 - 180,
          require("../../assets/home/images/header_10.png"),
          370,
          440,
          0,
          canvas.width / 2 - 210,
          canvas.height / 2 - 90,
          175,
          200
        )
      );

      // red A alphabet --- done

      images.push(
        new UploadedImage(
          363,
          220,
          require("../../assets/home/images/header_43.png"),
          50,
          50,
          0,
          canvas.width / 2 - 140,
          canvas.height / 2 - 35,
          95,
          100,
          -40
        )
      );

      // red building --- done

      images.push(
        new UploadedImage(
          canvas.width / 2,
          canvas.height / 2,
          require("../../assets/home/images/header_23.png"),
          0,
          0,
          0,
          canvas.width / 2 - 225,
          canvas.height / 2 + 30,
          145,
          115
        )
      );

      // man with only face --- done
      images.push(
        new UploadedImage(
          -300,
          550,
          require("../../assets/home/images/header_38.png"),
          165,
          165,
          0,
          canvas.width / 2 - 140,
          canvas.height / 2 - 8,
          165,
          165
        )
      );

      // hand folding person ---- done
      images.push(
        new UploadedImage(
          600,
          canvas.width,
          require("../../assets/home/images/header_49.png"),
          115,
          160,
          0,
          canvas.width / 2 - 120,
          canvas.height / 2 + 45,
          115,
          160
        )
      );

      // man with hand outside ellipse --- done
      images.push(
        new UploadedImage(
          500,
          canvas.width,
          require("../../assets/home/images/header_51.png"),
          110,
          155,
          0,
          canvas.width / 2 - 170,
          canvas.height / 2 + 75,
          95,
          150
        )
      );

      // building at left side in bottom --- done
      images.push(
        new UploadedImage(
          canvas.width / 2,
          canvas.height / 2,
          require("../../assets/home/images/header_24.png"),
          0,
          0,
          0,
          canvas.width / 2 - 360,
          canvas.height / 2 + 10,
          165,
          100
        )
      );

      // lady with the book --- DONE

      images.push(
        new UploadedImage(
          canvas.width / 2 + 17,
          canvas.height / 2 - 83,
          require("../../assets/home/images/header_14.png"),
          430,
          500,
          0,
          canvas.width / 2 - 105,
          canvas.height / 2 + 45,
          205,
          235
        )
      );

      //Circle with three colors of lady book --- done
      images.push(
        new UploadedImage(
          canvas.width / 2 + 260,
          canvas.height / 2 + 210,
          require("../../assets/home/images/header_3.png"),
          220,
          165,
          0,
          canvas.width / 2 + 25,
          canvas.height / 2 + 160,
          0,
          0
        )
      );

      //equipment --- done

      images.push(
        new UploadedImage(
          canvas.width / 2 + 45,
          canvas.height / 2 + 75,
          require("../../assets/home/images/header_1.png"),
          150,
          150,
          0,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0
        )
      );

      //ship done

      images.push(
        new UploadedImage(
          canvas.width / 2 - 250,
          canvas.height / 2 - 145,
          require("../../assets/home/images/header_47.png"),
          150,
          165,
          0,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0
        )
      );

      //circle with colors on glasses person --- DONE

      images.push(
        new UploadedImage(
          canvas.width / 2 - 445,
          canvas.height / 2 - 13,
          require("../../assets/home/images/header_4.png"),
          215,
          120,
          0,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0
        )
      );

      // person with lines and run pose ---done

      images.push(
        new UploadedImage(
          -45,
          77,
          require("../../assets/home/images/header_13_1.png"),
          295,
          260,
          0,
          canvas.width / 2 - 420,
          canvas.height / 2 - 62,
          135,
          115
        )
      );

      //head skull with red dot --- done

      images.push(
        new UploadedImage(
          340,
          87,
          require("../../assets/home/images/header_44.png"),
          95,
          90,
          0,
          canvas.width / 2 - 260,
          canvas.height / 2 - 137,
          60,
          57
        )
      );

      // person laptop above skull ---- done

      images.push(
        new UploadedImage(
          341,
          59,
          require("../../assets/home/images/header_58.png"),
          40,
          55,
          0,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0
        )
      );

      // PEN ---- done

      images.push(
        new UploadedImage(
          canvas.width / 2 - 330,
          -45,
          require("../../assets/home/images/header_11.png"),
          125,
          240,
          -3,
          canvas.width / 2 - 180,
          canvas.height / 2 - 190,
          45,
          72,
          -10
        )
      );

      // Map --- done
      images.push(
        new UploadedImage(
          canvas.width / 2 - 310,
          5,
          require("../../assets/home/images/header_54.png"),
          215,
          125,
          0,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0
        )
      );

      //AEROPLANE MAN ---- done
      images.push(
        new UploadedImage(
          canvas.width / 2 - 70,
          10,
          require("../../assets/home/images/header_20.png"),
          40,
          90,
          -20,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0
        )
      );

      // Aeroplane --- done

      images.push(
        new UploadedImage(
          canvas.width / 2 - 145,
          45,
          require("../../assets/home/images/header_2.png"),
          180,
          70,
          0,
          canvas.width / 2 + 70,
          canvas.height / 2 - 243,
          100,
          40
        )
      );

      // Skull with brain --- done
      images.push(
        new UploadedImage(
          canvas.width / 2 + 80,
          -20,
          require("../../assets/home/images/header_46.png"),
          125,
          135,
          0,
          canvas.width / 2 + 235,
          canvas.height / 2 - 145,
          80,
          50,
          0
        )
      );

      // Upper circle with man --- done
      images.push(
        new UploadedImage(
          canvas.width / 2 + 240,
          -180,
          require("../../assets/home/images/header_16.png"),
          325,
          280,
          0,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0
        )
      );

      // ellipse with circles and lines --- DONE

      images.push(
        new UploadedImage(
          145,
          220,
          require("../../assets/home/images/header_12.png"),
          270,
          200,
          0,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0
        )
      );

      //big red circle --- DONE

      images.push(
        new UploadedImage(
          -220,
          canvas.height - 95,
          require("../../assets/home/images/header_55.png"),
          675,
          550,
          0,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0
        )
      );

      // hand --- DONE

      images.push(
        new UploadedImage(
          55,
          canvas.height - 270,
          require("../../assets/home/images/header_7.png"),
          300,
          285,
          0,
          canvas.width / 2 - 345,
          canvas.height / 2 + 40,
          165,
          150,
          5
        )
      );

      // robotic hand --- done

      images.push(
        new UploadedImage(
          275,
          canvas.height - 185,
          require("../../assets/home/images/header_5.png"),
          255,
          235,
          0,
          canvas.width / 2 - 275,
          canvas.height / 2 + 100,
          100,
          100,
          5
        )
      );

      // insect

      images.push(
        new UploadedImage(
          canvas.width / 2 - 280,
          canvas.height - 115,
          require("../../assets/home/images/header_53.png"),
          150,
          115,
          0,
          canvas.width / 2 - 160,
          canvas.height / 2 + 175,
          70,
          55,
          90
        )
      );

      //person with book holding --- DONE

      images.push(
        new UploadedImage(
          75,
          canvas.height - 135,
          require("../../assets/home/images/header_40.png"),
          100,
          135,
          0,
          canvas.width / 2,
          canvas.height / 2,
          0,
          0
        )
      );
    }

    // Animation Loop
    function animate() {
      requestAnimationFrame(animate);
      c.clearRect(0, 0, canvas.width, canvas.height);
      imageDummy.forEach((image) => {
        // image.draw();
      });
      circles.forEach((object) => {
        object.update();
      });
      circleAboveImages.forEach((image) => {
        image.update();
      });
      staticImages.forEach((image) => {
        // image.draw();
      });
      images.forEach((image) => {
        image.draw();
      });
      images1.forEach((image) => {
        image.draw();
      });
    }

    init();
    animate();

    function animateOnScroll() {
      ScrollTrigger.create({
        trigger: ".spacer",
        scroller: scrollContainer,
        start: "top top", // Adjust the start position based on your preference
        onEnter: () => {
          // When scrolling down, apply the styles to display the div
          gsap.set(".lKv-people", {
            opacity: 1,
          });
        },
        onLeaveBack: () => {
          // When scrolling back up, apply the styles to hide the div
          gsap.set(".lKv-people", {
            opacity: 0,
          });
        },
      });
    }

    function toggleDivOnScroll() {
      const animationDuration = 1.5; // Adjust the duration of the animation in seconds
      const animationDelay = 0.5; // Adjust the delay before the animation starts in seconds
      let isActive = false; // Flag to track if animation is active

      ScrollTrigger.create({
        trigger: ".spacer",
        scroller: scrollContainer,
        start: "top top", // Adjust the start position based on your preference
        onEnter: () => {
          // When scrolling down, apply the styles to display the div
          // gsap.set(".lKv-people-item-l01", {
          //   display: "block",
          //   transform: "translate(0, 0)",
          //   delay: 0.5,
          // });
          gsap.fromTo(
            ".-l01",
            {
              transform: "translate(-573px, 272px)",
            },
            {
              transform: "translate(0, 0)",
              duration: 1.5,
              delay: 0.5,
            }
          );
          gsap.fromTo(
            ".-l02",
            {
              transform: "translate(-573px, 272px)",
            },
            {
              transform: "translate(0, 0)",
              duration: 1.5,
              delay: 0.5,
            }
          );
          gsap.fromTo(
            ".-l03",
            {
              transform: "translate(-573px, 272px)",
            },
            {
              transform: "translate(0, 0)",
              duration: 1.5,
              delay: 1,
            }
          );
          gsap.fromTo(
            ".-l04",
            {
              transform: "translate(-573px, 272px)",
            },
            {
              transform: "translate(0, 0)",
              duration: 1.5,
              delay: 0,
            }
          );
          gsap.fromTo(
            ".-l05",
            {
              transform: "translate(-573px, 272px)",
            },
            {
              transform: "translate(0, 0)",
              duration: 1.5,
              delay: 0.7,
            }
          );
          gsap.fromTo(
            ".-l06",
            {
              transform: "translate(-573px, 272px)",
            },
            {
              transform: "translate(0, 0)",
              duration: 1.5,
              delay: 0,
            }
          );
          gsap.fromTo(
            ".-l07",
            {
              transform: "translate(-573px, 272px)",
            },
            {
              transform: "translate(0, 0)",
              duration: 1.5,
              delay: 1.2,
            }
          );
          gsap.fromTo(
            ".-l08",
            {
              transform: "translate(-573px, 272px)",
            },
            {
              transform: "translate(0, 0)",
              duration: 1.5,
              delay: 0,
            }
          );
          gsap.fromTo(
            ".st1",
            {
              transform: "scale(0)",
            },
            {
              transform: "scale(1)",
              duration: 1,
              delay: 0,
            }
          );
          gsap.fromTo(
            ".st2",
            {
              transform: "scale(0)",
            },
            {
              transform: "scale(1)",
              duration: 1.3,
              delay: 0,
            }
          );
          gsap.fromTo(
            ".st3",
            {
              transform: "scale(0)",
            },
            {
              transform: "scale(1)",
              duration: 1.3,
              delay: 0.2,
            }
          );
          gsap.fromTo(
            ".st4",
            {
              transform: "scale(0)",
            },
            {
              transform: "scale(1)",
              duration: 1.3,
              delay: 0.3,
            }
          );
          gsap.fromTo(
            ".st5",
            {
              transform: "scale(0)",
            },
            {
              transform: "scale(1)",
              duration: 1.3,
              delay: 0.4,
            }
          );
          gsap.fromTo(
            ".st6",
            {
              transform: "scale(0)",
            },
            {
              transform: "scale(1)",
              duration: 1.3,
              delay: 0.5,
            }
          );
          gsap.fromTo(
            ".lKv-coreBall",
            {
              transform: "scale(0.5267, 0.5267)",
            },
            {
              transform: "translate(0px, -75.024px)",
            }
          );
          gsap.fromTo(
            ".lKv-subTitle-item > img ",
            {
              transform: "translate(0px, 0%)",
            },
            {
              transform: "translate(0px, 130%)",
            }
          );
          gsap.fromTo(
            ".cHeader-logo",
            {
              transform: "translate(-40px, 99.5825px)",
              top: 0,
              left: 0,
            },
            {
              transform: "scale(0.266,0.266)",
              top: "1.9rem",
              left: "0rem",
            }
          );
          gsap.fromTo(
            ".lKv-lead-text",
            {
              transform: "translate(0px,130%)",
            },
            {
              transform: "translate(0px, 0%)",
            }
          );
          gsap.fromTo(
            ".lKv-lead",
            {
              transform: "translate(0px, 130%)",
            },
            {
              transform: "translate(0px,0%)",
            }
          );
        },
        onLeaveBack: () => {
          // When scrolling back up, apply the styles to hide the div
          gsap.fromTo(
            ".lKv-people-item",
            {
              transform: "translate(0, 0)",
            },
            {
              transform: "translate(-573px, 272px)",
              duration: 1,
              delay: 0,
            }
          );
          gsap.fromTo(
            ".st",
            {
              transform: "scale(1)",
            },
            {
              transform: "scale(0)",
              duration: 0.5,
              delay: 0,
            }
          );
          gsap.fromTo(
            ".lKv-coreBall",
            { transform: "translate(0px, -108.024px)" },
            {
              transform: "scale(0.5267, 0.5267)",
            }
          );
          gsap.fromTo(
            ".lKv-subTitle-item > img ",
            {
              transform: "translate(0px, 130%)",
            },
            {
              transform: "translate(0px, 0%)",
            }
          );
          gsap.fromTo(
            ".cHeader-logo",
            {
              transform: "scale(0.266,0.266)",
              top: "1.9rem",
              left: "0rem",
            },
            {
              transform: "translate(0px, 108.5825px)",
              top: 0,
              left: 0,
            }
          );
          gsap.fromTo(
            ".lKv-lead-text",
            {
              transform: "translate(0px, 0%)",
            },
            {
              transform: "translate(0px,130%)",
            }
          );
          gsap.fromTo(
            ".lKv-lead",
            {
              transform: "translate(0px, 0%)",
            },
            {
              transform: "translate(0px,130%)",
            }
          );
        },
      });
    }

    // Call the function to start the animations
    animateOnScroll();
    toggleDivOnScroll();

    let scrollDirection = 1;

    function firstDivlVisionScrollAnimation() {
      const headOpenDiv = document.querySelector(
        ".lVision-section-image.-first"
      );
      const shipDiv = document.querySelector(".lVision-illust.-second");
      const shipDivImage = document.querySelector(
        ".lVision-illust.-second > img"
      );
      const penDiv = document.querySelector(".lVision-illust.-first");

      const runPoseDiv = document.querySelector(".lVision-illust.-third");

      gsap.to(headOpenDiv, {
        scrollTrigger: {
          trigger: ".lVision",
          scroller: scrollContainer,
          start: "top top",
          scrub: true,
          onEnter: () => {
            headOpenDiv.classList.add("cPlaySprite");
          },
          onUpdate: (self) => {
            console.log("SELF -------------", self);
            const progress = self.progress;
            // Determine the scroll direction based on the progress
            const currentScrollDirection = progress > 0.5 ? 1 : -1;
            // If the scroll direction changed, update the scrollDirection variable
            if (currentScrollDirection !== scrollDirection) {
              scrollDirection = currentScrollDirection;
            }
            const updatedValueY =
              35.8191 + 200 * progress * currentScrollDirection;
            if (updatedValueY > -36 && updatedValueY < 36) {
              headOpenDiv.style.transform = `matrix3d(
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            ${updatedValueY},
            0,
            1
          )`;
            }
          },
        },
      });

      gsap.to(shipDiv, {
        scrollTrigger: {
          trigger: ".lVision",
          scroller: scrollContainer,
          start: "top top",
          scrub: true,
          onUpdate: (self) => {
            console.log("SELF -------------", self);
            const progress = self.progress;
            // Determine the scroll direction based on the progress
            const currentScrollDirection = progress > 0.5 ? 1 : -1;
            // If the scroll direction changed, update the scrollDirection variable
            if (currentScrollDirection !== scrollDirection) {
              scrollDirection = currentScrollDirection;
            }
            const updatedValueY = 150 * progress;
            const updatedValueRotationImg = progress * 75;
            if (updatedValueRotationImg < 27) {
              shipDivImage.style.transform = `rotate(${-updatedValueRotationImg}deg)`;
            }
            if (updatedValueY > -45 && updatedValueY < 45) {
              shipDiv.style.transform = `matrix3d(
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            ${updatedValueY},
            0,
            1
          )`;
            }
          },
        },
      });
      gsap.to(penDiv, {
        scrollTrigger: {
          trigger: ".lVision",
          scroller: scrollContainer,
          start: "top top",
          scrub: true,
          onUpdate: (self) => {
            const progress = self.progress;
            const updatedValueY = -55.1816 + 200 * progress;
            if (updatedValueY > -56 && updatedValueY < 15) {
              penDiv.style.transform = `rotate(10deg) matrix3d(
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            ${updatedValueY},
            0,
            1
          )`;
            }
          },
        },
      });

      gsap.to(runPoseDiv, {
        scrollTrigger: {
          trigger: ".lVision",
          scroller: scrollContainer,
          start: "top top",
          scrub: true,
          onUpdate: (self) => {
            const progress = self.progress;
            const updatedValueY = 150 * progress;
            if (updatedValueY > -15 && updatedValueY < 15) {
              runPoseDiv.style.transform = `matrix3d(
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            ${updatedValueY},
            0,
            1
          )`;
            }
          },
        },
      });
    }

    function secondDivlVisionScrollAnimation() {
      const nodeDiv = document.querySelector(".lVision-node.-left");
      const cartDiv = document.querySelector(".lVision-illust.-forth");
      const cartDivImage = document.querySelector(
        ".lVision-illust.-forth > img"
      );

      const skullWithBrainDiv = document.querySelector(
        ".lVision-illust.-fifth"
      );
      const skullWithBrainDivImage = document.querySelector(
        ".lVision-illust.-fifth > picture  > img"
      );

      gsap.to(nodeDiv, {
        scrollTrigger: {
          trigger: ".lVision",
          scroller: scrollContainer,
          start: "top top",
          scrub: true,
          onUpdate: (self) => {
            const progress = self.progress;
            // Determine the scroll direction based on the progress
            const currentScrollDirection = progress > 0.5 ? 1 : -1;
            // If the scroll direction changed, update the scrollDirection variable
            if (currentScrollDirection !== scrollDirection) {
              scrollDirection = currentScrollDirection;
            }
            const updatedValueY = 200 * progress * currentScrollDirection;
            if (updatedValueY > -55 && updatedValueY < 36) {
              nodeDiv.style.transform = `matrix3d(
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            ${updatedValueY},
            0,
            1
          )`;
            }
          },
        },
      });
      gsap.to(cartDiv, {
        scrollTrigger: {
          trigger: ".lVision",
          scroller: scrollContainer,
          start: "top top",
          scrub: true,
          onUpdate: (self) => {
            const progress = self.progress;
            // Determine the scroll direction based on the progress
            const currentScrollDirection = progress > 0.5 ? 1 : -1;
            // If the scroll direction changed, update the scrollDirection variable
            if (currentScrollDirection !== scrollDirection) {
              scrollDirection = currentScrollDirection;
            }
            const updatedValueY = 100 * progress * currentScrollDirection;
            const updatedValueRotationImg = progress * 75;
            if (updatedValueRotationImg < 34) {
              cartDivImage.style.transform = `rotate(${-updatedValueRotationImg}deg)`;
            }
            if (updatedValueY > -9 && updatedValueY < 10) {
              cartDiv.style.transform = `matrix3d(
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            ${updatedValueY},
            0,
            1
          )`;
            }
          },
        },
      });

      gsap.to(skullWithBrainDiv, {
        scrollTrigger: {
          trigger: ".lVision",
          scroller: scrollContainer,
          start: "top top",
          scrub: true,
          onUpdate: (self) => {
            console.log("SELF -------------", self);
            const progress = self.progress;
            // Determine the scroll direction based on the progress
            const currentScrollDirection = progress > 0.5 ? 1 : -1;
            // If the scroll direction changed, update the scrollDirection variable
            if (currentScrollDirection !== scrollDirection) {
              scrollDirection = currentScrollDirection;
            }
            const updatedValueRotationImg = progress * 75;
            const updatedValueY = -75.0279 + 150 * progress;
            if (updatedValueRotationImg < 50) {
              skullWithBrainDivImage.style.transform = `rotate(${updatedValueRotationImg}deg)`;
            }
            if (updatedValueY > -50 && updatedValueY < 10) {
              skullWithBrainDiv.style.transform = `matrix3d(
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            ${updatedValueY},
            0,
            1
          )`;
            }
          },
        },
      });
    }

    function thirdDivlVisionScrollAnimation() {
      const handOpenDiv = document.querySelector(
        ".lVision-section-image.-third"
      );
      const skullWithDotDiv = document.querySelector(".lVision-illust.-sixth");
      const skullWithDotDivImage = document.querySelector(
        ".lVision-illust.-sixth > picture > img"
      );

      gsap.to(handOpenDiv, {
        scrollTrigger: {
          trigger: ".lVision",
          scroller: scrollContainer,
          start: "+=65%",
          scrub: true,
          onEnter: () => {
            handOpenDiv.classList.add("cPlaySpriteHand");
          },
          onUpdate: (self) => {
            console.log("SELF -------------", self);
            const progress = self.progress;
            // Determine the scroll direction based on the progress
            const currentScrollDirection = progress > 0.5 ? 1 : -1;
            // If the scroll direction changed, update the scrollDirection variable
            if (currentScrollDirection !== scrollDirection) {
              scrollDirection = currentScrollDirection;
            }
            const updatedValueY =
              12.3016 + 200 * progress * currentScrollDirection;
            if (updatedValueY > -36 && updatedValueY < 36) {
              handOpenDiv.style.transform = `matrix3d(
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            ${updatedValueY},
            0,
            1
          )`;
            }
          },
        },
      });
      gsap.to(skullWithDotDiv, {
        scrollTrigger: {
          trigger: ".lVision",
          scroller: scrollContainer,
          start: "+=50%",
          scrub: true,
          onUpdate: (self) => {
            console.log("SELF -------------", self);
            const progress = self.progress;
            // Determine the scroll direction based on the progress
            const currentScrollDirection = progress > 0.5 ? 1 : -1;
            // If the scroll direction changed, update the scrollDirection variable
            if (currentScrollDirection !== scrollDirection) {
              scrollDirection = currentScrollDirection;
            }
            const updatedValueY = 150 * progress;
            const updatedValueRotationImg = 30 + progress * 100;
            console.log(
              "UPD UPDATED VALUE ROTATION: " + updatedValueRotationImg
            );
            if (updatedValueRotationImg < 50) {
              skullWithDotDivImage.style.transform = `rotate(${updatedValueRotationImg}deg)`;
            }
            if (updatedValueY > -45 && updatedValueY < 45) {
              skullWithDotDiv.style.transform = `matrix3d(
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            ${updatedValueY},
            0,
            1
          )`;
            }
          },
        },
      });
    }

    firstDivlVisionScrollAnimation();
    secondDivlVisionScrollAnimation();
    thirdDivlVisionScrollAnimation();
  }, []);

  return (
    <div>
      <div className="spacer">
        <div className="lKv-subTitle" data-kv-subtitle="">
          <div
            className="lKv-subTitle-item -lm01"
            data-kv-subtitle-item=""
            style={{ overflow: "hidden" }}
          >
            <img
              className="lKv-subTitle-item-image1"
              src="https://rara.ritsumei.ac.jp/assets/img/index/kv/b-logo_sub01.svg"
              width="103"
              height="5"
              alt=""
              loading="lazy"
              srcSet="
                    https://rara.ritsumei.ac.jp/assets/img/index/kv/b-logo_sub01.svg 1x,
                    https://rara.ritsumei.ac.jp/assets/img/index/kv/b-logo_sub01.svg 2x
                "
            />
          </div>
          <div
            className="lKv-subTitle-item -lm02"
            data-kv-subtitle-item=""
            style={{ overflow: "hidden" }}
          >
            <img
              className="lKv-subTitle-item-image2"
              src="https://rara.ritsumei.ac.jp/assets/img/index/kv/b-logo_sub02.svg"
              width="84"
              height="5"
              alt=""
              loading="lazy"
              srcSet="
                    https://rara.ritsumei.ac.jp/assets/img/index/kv/b-logo_sub02.svg 1x,
                    https://rara.ritsumei.ac.jp/assets/img/index/kv/b-logo_sub02.svg 2x
                "
            />
          </div>
          <div
            className="lKv-subTitle-item -lm03"
            data-kv-subtitle-item=""
            style={{ overflow: "hidden" }}
          >
            <img
              className="lKv-subTitle-item-image3"
              src="https://rara.ritsumei.ac.jp/assets/img/index/kv/b-logo_sub03.svg"
              width="166"
              height="13"
              alt=""
              loading="lazy"
              srcSet="
                    https://rara.ritsumei.ac.jp/assets/img/index/kv/b-logo_sub03.svg 1x,
                    https://rara.ritsumei.ac.jp/assets/img/index/kv/b-logo_sub03.svg 2x
                "
            />
          </div>
        </div>
        <div
          className="lKv-coreBall"
          data-kv-coreball=""
          style={{ transform: "scale(0.5267, 0.5267)" }}
        >
          <picture>
            <source
              srcSet="
                    https://rara.ritsumei.ac.jp//assets/img/index/kv/core_ball.png.webp
                "
              type="image/webp"
            />
            <img
              src="https://rara.ritsumei.ac.jp//assets/img/index/kv/core_ball.png"
              width="260"
              height="260"
              alt=""
              loading="lazy"
            />
          </picture>
        </div>
        <div
          className="cFlatText lKv-lead"
          data-flat-text=""
          data-kv-lead=""
          style={{
            padding: "0px 28.075px",
            transform: "scaleX(1.05)",
            top: "39pc",
            zIndex: 2,
          }}
        >
          <div
            className="lKv-lead-main"
            data-kv-lead-item=""
            style={{ overflow: "hidden" }}
          >
            <p
              className="lKv-lead-text"
              style={{
                transform: "translate(0px, 130%)",
                willChange: "transform",
              }}
            >
              次世代研究大学<span className="_ls0">をつくる</span>
            </p>
          </div>
          <div
            className="lKv-lead-sub"
            data-kv-lead-item=""
            style={{ overflow: "hidden" }}
          >
            <p
              className="lKv-lead-text"
              style={{
                transform: "translate(0px, 130%)",
                willChange: "transform",
              }}
            >
              先進研究の創造を通じて
            </p>
          </div>
        </div>
        <div className="lKv-people" data-kv-people="">
          <img
            className="lKv-people-item -l01 people-item"
            data-kv-people-item=""
            src="https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people01.svg"
            width="28"
            height="52"
            alt=""
            loading="lazy"
            srcSet="
                https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people01.svg 1x,
                https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people01.svg 2x
                "
            style={{ transform: "translate(-573px, 272px)" }}
          />
          <img
            className="lKv-people-item -l02"
            data-kv-people-item=""
            src="https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people02.svg"
            width="31"
            height="50"
            alt=""
            loading="lazy"
            srcSet="
                https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people02.svg 1x,
                https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people02.svg 2x
                "
            style={{ transform: "translate(-573px, 272px)" }}
          />

          <img
            className="lKv-people-item -l03"
            data-kv-people-item=""
            src="https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people03.svg"
            width="54"
            height="55"
            alt=""
            loading="lazy"
            srcSet="
                https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people03.svg 1x,
                https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people03.svg 2x
                "
            style={{ transform: "translate(-573px, 272px)" }}
          />
          <img
            className="lKv-people-item -l04"
            data-kv-people-item=""
            src="https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people04.svg"
            width="58"
            height="57"
            alt=""
            loading="lazy"
            srcSet="
                https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people04.svg 1x,
                https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people04.svg 2x
                "
            style={{ transform: "translate(-573px, 272px)" }}
          />
          <img
            className="lKv-people-item -l05"
            data-kv-people-item=""
            src="https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people05.svg"
            width="28"
            height="48"
            alt=""
            loading="lazy"
            srcSet="
                https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people05.svg 1x,
                https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people05.svg 2x
                "
            style={{ transform: "translate(-573px, 272px)" }}
          />
          <img
            className="lKv-people-item -l06"
            data-kv-people-item=""
            src="https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people06.svg"
            width="31"
            height="54"
            alt=""
            loading="lazy"
            srcSet="
                https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people06.svg 1x,
                https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people06.svg 2x
                "
            style={{ transform: "translate(573px, 272px)" }}
          />
          <img
            className="lKv-people-item -l07"
            data-kv-people-item=""
            src="https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people07.svg"
            width="29"
            height="51"
            alt=""
            loading="lazy"
            srcSet="
                https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people07.svg 1x,
                https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people07.svg 2x
                "
            style={{ transform: "translate(573px, 272px)" }}
          />
          <img
            className="lKv-people-item -l08"
            data-kv-people-item=""
            src="https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people08.svg"
            width="31"
            height="50"
            alt=""
            loading="lazy"
            srcSet="
                https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people08.svg 1x,
                https://rara.ritsumei.ac.jp/assets/img/index/kv/people/b-intro-people08.svg 2x
                "
            style={{ transform: "translate(573px, 272px)" }}
          />
        </div>
        <div className="lKv-vision">
          <div
            className="lKv-vision-title"
            data-kv-vision-title=""
            style={{ top: "183px" }}
          >
            <svg
              x="0px"
              y="0px"
              viewBox="0 0 767.78 151.37"
              style={{ willChange: "transform" }}
            >
              <path
                className="st st1"
                data-svg-title-item=""
                d="M159.69,3.23v3.15c-19.74,1.68-25.83,18.27-38.85,48.72l-40.11,95.76h-2.94L30.32,37.25            C24.02,21.92,19.19,8.48,0.5,6.38V3.23h66.57v3.15C37.46,9.32,47.12,26.12,52.58,39.35l33.6,81.06l24.78-59.43            c18.06-43.05,21.42-49.98-10.5-54.6V3.23H159.69z"
                style={{ transformOrigin: "center", transform: "scale(0)" }}
              ></path>
              <path
                className="st st2"
                data-svg-title-item=""
                d="M217.01,111.59c0.63,21.63,0.84,27.93,26.04,31.29v3.15h-70.56v-3.15c25.2-3.36,25.41-9.66,26.04-31.29V37.67            c-0.63-21.63-0.84-27.93-26.04-31.29V3.23h70.56v3.15c-25.2,3.36-25.41,9.66-26.04,31.29V111.59z"
                style={{ transformOrigin: "center", transform: "scale(0)" }}
              ></path>
              <path
                className="st st3"
                data-svg-title-item=""
                d="M344.48,40.19h-3.36C337.76,23.18,332.3,6.8,311.51,6.8c-13.44,0-24.57,9.24-24.57,23.1            c0,36.33,66.15,35.07,66.15,77.49c0,27.09-26.88,41.16-51.03,41.16c-12.81,0-26.25-3.78-36.96-10.71l-6.09-35.7h3.78            c5.25,20.16,19.32,40.11,42.42,40.11c15.54,0,27.72-9.24,27.72-25.62c0-37.38-64.26-34.02-64.26-76.02            c0-24.57,24.36-40.11,46.83-40.11c10.71,0,21.42,3.15,30.66,8.19L344.48,40.19z"
                style={{ transformOrigin: "center", transform: "scale(0)" }}
              ></path>
              <path
                className="st st4"
                data-svg-title-item=""
                d="M414.41,111.59c0.63,21.63,0.84,27.93,26.04,31.29v3.15h-70.56v-3.15c25.2-3.36,25.41-9.66,26.04-31.29V37.67            c-0.63-21.63-0.84-27.93-26.04-31.29V3.23h70.56v3.15c-25.2,3.36-25.41,9.66-26.04,31.29V111.59z"
                style={{ transformOrigin: "center", transform: "scale(0)" }}
              ></path>
              <path
                className="st st5"
                data-svg-title-item=""
                d="M522.83,0.71c-43.89,0-76.65,28.98-76.65,73.71c0,45.36,32.55,74.13,76.86,74.13            c44.1,0,76.86-28.77,76.86-73.92C599.91,37.25,576.6,0.71,522.83,0.71z M525.56,143.51c-37.8,0-55.02-41.58-55.02-74.13            c0-28.35,14.49-63.63,50.61-63.63c32.13,0,53.76,35.28,54.39,72.45C575.54,108.23,560.21,143.51,525.56,143.51z"
                style={{ transformOrigin: "center", transform: "scale(0)" }}
              ></path>
              <path
                className="st st6"
                data-svg-title-item=""
                d="M740.39,113.06l-1.05-76.65c-0.21-19.95-5.67-25.83-29.4-30.03V3.23h57.33v3.15            c-14.49,1.89-17.22,9.87-18.9,23.52c-2.94,23.1-1.89,73.71-0.84,119.49l-2.73,0.63c-33.6-39.69-70.98-76.44-106.47-114.66V74            c0,52.08-1.26,62.79,29.19,68.88v3.15h-62.79v-3.15c28.35-2.94,27.3-22.26,27.3-69.93v-31.5c0-21-3.36-29.19-30.03-35.07V3.23h34.65            L740.39,113.06z"
                style={{ transformOrigin: "center", transform: "scale(0)" }}
              ></path>
            </svg>
          </div>
        </div>
        <canvas id="canvas1" width="1538" height="800"></canvas>
      </div>
      <div className="lVision" data-vision="">
        <div className="lVision-contents">
          <div className="lVision-section -first -flex" data-vision-section="1">
            <div className="lVision-section-writing -first">
              <div
                className="cFlatText lVision-section-writing-text -mb"
                data-flat-text=""
                style={{
                  padding: "0px 8.425px",
                  transform: "scaleX(1.05)",
                  fontFamily: "sans-serif",
                  color: "#707070",
                }}
              >
                立命館学園が掲げる、
                <br />
                <a
                  className="cLink lVision-section-link"
                  href="http://www.ritsumei.ac.jp/features/r2030/"
                  target="_blank"
                >
                  学園ビジョンR2030{" "}
                </a>
                <span className="_cl1">「</span>挑戦をもっと自由に
                <span className="_cr1">」</span>
                <br className="_sp" />
                のもと、
                <br className="_pc" />
                立命館大学では
                <br className="_sp" />
                <span className="_cl1">「</span>チャレンジデザイン
                <span className="_cr1">」</span>を策定しています。
                <br />
                人類に共通する社会課題を解決するため、
                <br />
                社会共生価値の創造とイノベーションに取り組む
                <br />
                <span className="_cl1">「</span>
                次世代研究大学」の実現を目指します。
                <br />
              </div>
              <div
                className="cFlatText lVision-section-writing-text"
                data-flat-text=""
                style={{
                  padding: "0px 8.425px",
                  transform: "scaleX(1.05)",
                  color: "#707070",
                  fontFamily: "sans-serif",
                }}
              >
                Ritsumeikan Advanced Research Academy
                <br />
                (立命館先進研究アカデミー)は、次世代研究大学として、
                <br className="_pc" />
                未来社会に貢献する新しい研究分野の創出を
                <br className="_pc" />
                目指して設立されました。
              </div>
            </div>
            <div
              className="lVision-section-image -first -view"
              data-play-sprite=""
              data-play-sprite-step="25"
              data-play-sprite-duration="0.8"
              style={{
                backgroundImage: `url(${headOpenBGImage})`,
                transform: "matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,35.8191,0,1)",
              }}
              data-scroll-speed="0.7"
              data-scroll=""
            ></div>
            <div
              className="lVision-illust -first -view"
              data-scroll=""
              data-illust="1"
              data-scroll-speed="-0.5"
              style={{
                transform:
                  "rotate(10deg) matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,-55.1816,0,1)",
              }}
            >
              <picture>
                <source
                  srcSet="
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/sp/1x/b-vision_illust09.png    1x,
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/sp/2x/b-vision_illust09@2x.png 2x
                    "
                  media="(max-width: 767px)"
                />
                <img
                  src="https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_illust09.png"
                  width="91"
                  height="100"
                  alt=""
                  loading="lazy"
                  srcSet="
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_illust09.png    1x,
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/2x/b-vision_illust09@2x.png 2x
                    "
                  style={{
                    transform: "translate3d(0px, 0px, 0px) rotate(-13.2308deg)",
                  }}
                />
              </picture>
            </div>
            <div
              className="lVision-illust -second -view"
              data-scroll=""
              data-illust="2"
              data-scroll-speed="-0.3"
              style={{
                transform: "matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1)",
              }}
            >
              <img
                src="https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_illust05.png"
                width="73"
                height="74"
                alt=""
                loading="lazy"
                srcSet="
                    https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_illust05.png    1x,
                    https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/2x/b-vision_illust05@2x.png 2x
                    "
                style={{
                  transform: "translate3d(0px, 0px, 0px) rotate(0deg)",
                }}
              />
            </div>
            <div
              className="lVision-illust -third -view"
              data-scroll=""
              data-illust="3"
              data-scroll-speed="-0.5"
              style={{
                transform: "matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1)",
              }}
            >
              <picture>
                <source
                  srcSet="
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/sp/1x/b-vision_illust03.png
                    "
                  media="(max-width: 767px)"
                />
                <img
                  src="https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_illust03.png"
                  width="138"
                  height="113"
                  alt=""
                  loading="lazy"
                  srcSet="
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_illust03.png    1x,
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/2x/b-vision_illust03@2x.png 2x
                    "
                  style={{
                    transform: "translate3d(0px, 0px, 0px) rotate(13.2308deg)",
                  }}
                />
              </picture>
            </div>
          </div>
          <div className="lVision-section -second" data-vision-section="2">
            <div className="lVision-section-writing">
              <div
                className="cFlatText lVision-section-writing-text -mb -isTracking-short"
                data-flat-text=""
                style={{ padding: "0px 14.25px", transform: "scaleX(1.05)" }}
              >
                RARAとは、立命館大学の先導的・先進的研究拠点の形成に向けてリーダーシップを発揮することが
                <span className="_nowrap">期待される</span>
                中核研究者の集まり(アカデミー)のことです。
                <br className="_sp" />
                RARAを基盤にする研究者(RARAフェロー)は、本大学の核となり、他の研究者を巻き込み、先進研究を構想・企画・牽引することを目指します。
              </div>
              <div
                className="cFlatText lVision-section-writing-text"
                data-flat-text=""
                style={{ padding: "0px 14.25px", transform: "scaleX(1.05)" }}
              >
                RARAには、RARAフェロー同士の融合や他大学・他研究機関との連携を通じて、
                <br />
                新たな価値を生み出す先進的な学際研究拠点の創成に結びつける役割を
                <br />
                担う狙いもあります。互いに異分野の研究を理解し、
                <br className="_sp" />
                それらを融合した
                <br className="_pc" />
                新たな研究分野、
                <br className="_sp" />
                学際領域を創造することで、
                <br />
                世界と伍する先進研究拠点の
                <br className="_sp" />
                早期実現を目指します。
              </div>
            </div>
            <div className="lVision-section-figure">
              <picture>
                <source
                  srcSet="
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/sp/1x/b-vision_figure.png    1x,
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/sp/2x/b-vision_figure@2x.png 2x
                    "
                  media="(max-width: 767px)"
                />
                <img
                  className="lVision-section-figure-item"
                  src="https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_figure.png"
                  width="802"
                  height="470"
                  alt=""
                  loading="lazy"
                  srcSet="
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_figure.png    1x,
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/2x/b-vision_figure@2x.png 2x
                    "
                />
              </picture>
              <div
                className="cFlatText lVision-section-figure-text"
                data-flat-text=""
                style={{ padding: "0px 14.25px", transform: "scaleX(1.05)" }}
              >
                先進研究拠点の創造と共生価値の創成
              </div>
            </div>
            <div
              className="lVision-illust -forth -view"
              data-scroll=""
              data-illust="4"
              data-scroll-speed="-0.3"
              style={{
                transform: "matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1)",
              }}
            >
              <img
                src="https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_illust04.png"
                width="74"
                height="92"
                alt=""
                loading="lazy"
                srcSet="
                    https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_illust04.png    1x,
                    https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/2x/b-vision_illust04@2x.png 2x
                    "
                style={{
                  transform: "translate3d(0px, 0px, 0px) rotate(0deg)",
                }}
              />
            </div>
            <div
              className="lVision-illust -fifth -view"
              data-scroll=""
              data-illust="5"
              data-scroll-speed="-0.3"
              style={{
                transform: "matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,-75.0279,0,1)",
              }}
            >
              <picture>
                <source
                  srcSet="
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/sp/1x/b-vision_illust06.png    1x,
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/sp/2x/b-vision_illust06@2x.png 2x
                    "
                  media="(max-width: 767px)"
                />
                <img
                  src="https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_illust06.png"
                  width="71"
                  height="75"
                  alt=""
                  loading="lazy"
                  srcSet="
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_illust06.png    1x,
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/2x/b-vision_illust06@2x.png 2x
                    "
                  style={{
                    transform: "translate3d(0px, 0px, 0px) rotate(46.3077deg)",
                  }}
                />
              </picture>
            </div>
            <div
              className="lVision-node -left -view"
              data-scroll=""
              data-scroll-speed="0.7"
              style={{
                transform: "matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1)",
              }}
            >
              <img
                src="https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_illust10.png"
                width="934"
                height="695"
                alt=""
                loading="lazy"
                srcSet="
                    https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_illust10.png    1x,
                    https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/2x/b-vision_illust10@2x.png 2x
                    "
              />
            </div>
            <div className="lVision-node -right">
              <img
                src="https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_illust11.png"
                width="124"
                height="276"
                alt=""
                loading="lazy"
                srcSet="
                    https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_illust11.png    1x,
                    https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/2x/b-vision_illust11@2x.png 2x
                    "
              />
            </div>
          </div>
          <div className="lVision-section -third" data-vision-section="3">
            <div className="lVision-section-writing -third">
              <div
                className="cFlatText lVision-section-writing-text"
                data-flat-text=""
                style={{ padding: "0px 12.45px", transform: "scaleX(1.05)" }}
              >
                RARAコロキアムとは、RARAフェローがそれぞれの目標達成に向けて、
                <br />
                中核研究者としてのスキルを研鑽する場です。RARAフェロー同士が切磋琢磨しあい、
                <br />
                新しい学術領域・先進研究の創生に向けた活動準備を行います。
              </div>
              <div
                className="cFlatText lVision-section-writing-text"
                data-flat-text=""
                style={{ padding: "0px 12.45px", transform: "scaleX(1.05)" }}
              >
                RARAコモンズでは、RARAでの活動で得られた研究成果の発信を中心に行います。
                <br />
                RARAフェローがNodes(結合点)として、
                <br className="_sp" />
                他の研究者や研究機関と繋がりをもつことで、
                <br />
                研究活動のさらなる加速をはかります。
              </div>
            </div>
            <div
              className="lVision-section-image -third -view"
              data-play-sprite=""
              data-play-sprite-step="24"
              data-play-sprite-duration="0.8"
              style={{
                backgroundImage: `url(${handOpenBGImage})`,
                backgroundSize: "cover",
                transform: "matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,12.3016,0,1)",
              }}
              data-scroll=""
              data-scroll-speed="0.7"
            ></div>
            <div
              className="lVision-illust -sixth -view"
              data-scroll=""
              data-scroll-speed="-0.5"
              data-illust="6"
              style={{
                transform: "matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,-2.02998,,0,1)",
              }}
            >
              <picture>
                <source
                  srcSet="
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/sp/1x/b-vision_illust07.png    1x,
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/sp/2x/b-vision_illust07@2x.png 2x
                    "
                  media="(max-width: 767px)"
                />
                <img
                  src="https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_illust07.png"
                  width="68"
                  height="66"
                  alt=""
                  loading="lazy"
                  srcSet="
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/1x/b-vision_illust07.png    1x,
                        https://rara.ritsumei.ac.jp/assets/img/index/vision/pc/2x/b-vision_illust07@2x.png 2x
                    "
                  style={{
                    transform: "translate3d(0px, 0px, 0px) rotate(46.3077deg)",
                  }}
                />
              </picture>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default index;
